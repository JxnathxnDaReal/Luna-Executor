﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Luna
{
    public partial class Form2 : Form
    {
        Timer time = new Timer();
        public Point mouseLocation;

        public Form2()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (keytext.Text == "WEBYPASSINBYFRONWITHTISONE")
            {
                Form1 f1 = new Form1();
                f1.Show(); // Show the main form
                this.Hide(); // Hide the key form after success
            }
            else
            {
                MessageBox.Show("Wrong key. Please try again.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                keytext.Clear();
                keytext.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                // Replace with your Discord invite link
                string discordInviteLink = "https://discord.gg/WrUfmTksCn";

                // Open the Discord invite link in the default browser
                Process.Start(new ProcessStartInfo
                {
                    FileName = discordInviteLink,
                    UseShellExecute = true
                });
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
